
module.exports = {
    kGetDataErrorInfo: "数据获取失败"
}