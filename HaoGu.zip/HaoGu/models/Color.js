
module.exports = {
	c1: '#e64340',    // red
	c2: '#09bb07'     // green
}
