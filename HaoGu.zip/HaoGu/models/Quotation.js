
function Quotation(price, zd, zdf, open, high, low, hsl, syl, sjl, cjl, jl, zz, cje, lb, ltsz, date, time, color, goodsId) {
	this.price = price, 
	this.zd = zd, 
	this.zdf = zdf, 
	this.open = open, 
	this.high = high, 
	this.low = low, 
	this.hsl = hsl, 
	this.syl = syl, 
	this.sjl = sjl, 
	this.cjl = cjl, 
	this.jl = jl, 
	this.zz = zz, 
	this.cje = cje, 
	this.lb = lb, 
	this.ltsz = ltsz,
	this.date = date,
	this.time = time,
	this.color = color,
	this.goodsId = goodsId
}

module.exports = Quotation
