
function RelativeItem(goodsId, name, code, price, zdf, color) {
	this.goodsId = goodsId
	this.name = name
	this.code = code
	this.price = price
	this.zdf = zdf
	this.color = color
}

module.exports = RelativeItem
