
function Quotation(price, zd, zdf, open, high, low, hsl, zs, ds, cjl, jl, pj, cje, lb, zf, date, time, color, goodsId) {
	this.price = price, 
	this.zd = zd, 
	this.zdf = zdf, 
	this.open = open, 
	this.high = high, 
	this.low = low, 
	this.hsl = hsl, 
	this.zs = zs, 
	this.ds = ds, 
	this.cjl = cjl, 
	this.jl = jl, 
	this.pj = pj, 
	this.cje = cje, 
	this.lb = lb, 
	this.zf = zf,
	this.date = date,
	this.time = time,
	this.color = color,
	this.goodsId = goodsId
}

module.exports = Quotation
