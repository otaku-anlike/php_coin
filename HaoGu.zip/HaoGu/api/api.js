var haogu = require('./haogu.js')
var stock = require('./stock.js')
var kanpan = require('./kanpan.js')
var news = require('./news.js')

module.exports = {
    haogu: haogu,
    stock: stock,
    kanpan: kanpan,
    news: news
}